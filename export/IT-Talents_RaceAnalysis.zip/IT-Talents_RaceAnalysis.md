
# IT-Talents Race Analysis
### Moritz Göckel

## Table of Content

### 1. Loading and Cleaning

### 2. Analyzing
2.1. Does the weather affect the fuel consumption?

2.2. Which track is the most popular?

2.3. Cont' fuel_consumption and weather

2.4. Cont' popular tracks and pareto's law

2.5. Which track gets finished more/less often?

2.6. How does fuel_consumption differ on multiple tracks?

2.7. How much money do the players pay on the different tracks?

2.8. Lets find correlations

2.9. Is there a correlation between the popularity of a track and the money?

2.10. What is the most likely weather?3.11 On which weather do the player spend the most money?

2.11. On which weather do the player spend the most money?

2.12. Is the opponent or the challenger more likely to win?

2.13. Do older accounts win over newer accouts?

2.14. How many races get finished?

2.15. On which weekdays happen the most races?

2.16. At which times happen the most races?

2.17. How did the amount of races per month develope?

### 3. Predicting
3.1. Features

3.2. Training and test data

3.3. Machine Learning

3.4. Predicting


```python
# We want inline charts
%matplotlib inline
```

Importing the basic libraries


```python
import pandas as pd # For data management
import numpy as np # For math and array functions
import matplotlib.pyplot as plt # For plotting
```

## 1. Loading and Cleaning
We will load the data and check if we need to clean something up


```python
# Loading the dataset with pandas
allRaces = pd.read_csv('races.csv', sep=';', index_col='id')
```


```python
# having a quick peek at the header
list(allRaces)
```




    ['race_created',
     'race_driven',
     'track_id',
     'challenger',
     'opponent',
     'money',
     'fuel_consumption',
     'winner',
     'status',
     'forecast',
     'weather']




```python
# checking out how the values could look like
allRaces.values[1]
```




    array(['06.03.2012', '06.03.2012 00:03', 12, 5, 4, 30, '0.63', 4,
           'finished',
           'a:4:{s:5:"sunny";i:70;s:5:"rainy";i:15;s:8:"thundery";i:0;s:5:"snowy";i:15;}',
           'sunny'], dtype=object)




```python
# Fuel consumption is a string but should be a number, so lets fix that
allRaces[['fuel_consumption']] = allRaces[['fuel_consumption']].apply(pd.to_numeric, errors='coerce')
```


```python
allRaces.values[1] # Now fuel consumption is a nice float variable
```




    array(['06.03.2012', '06.03.2012 00:03', 12, 5, 4, 30, 0.63, 4, 'finished',
           'a:4:{s:5:"sunny";i:70;s:5:"rainy";i:15;s:8:"thundery";i:0;s:5:"snowy";i:15;}',
           'sunny'], dtype=object)



There will be more to change and to clean later, but we will just do that as soon as we need to

## 2. Analyzing
In this chapter we answer some questions about the data 

### 2.1 Does the weather affect the fuel consumption?
This question can only be awnsered by completed races. Therefore we only include finished races


```python
finished = allRaces.loc[allRaces['status'] == 'finished'] # Select all the finished races
finished.groupby(['weather'], as_index=False).mean()[['weather', 'fuel_consumption']] # Get the mean of every weather
```




<div>
<style>
    .dataframe thead tr:only-child th {
        text-align: right;
    }

    .dataframe thead th {
        text-align: left;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>weather</th>
      <th>fuel_consumption</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>rainy</td>
      <td>9.807224</td>
    </tr>
    <tr>
      <th>1</th>
      <td>snowy</td>
      <td>9.790905</td>
    </tr>
    <tr>
      <th>2</th>
      <td>sunny</td>
      <td>9.495855</td>
    </tr>
    <tr>
      <th>3</th>
      <td>thundery</td>
      <td>9.774463</td>
    </tr>
  </tbody>
</table>
</div>



There seems to be no correlation. The averages of the fuel_consumption are the same in all kinds of weather conditions.

### 2.2 Which track is the most popular?
For this question we regard all races again


```python
#Lets get the most populat tracks
plt.hist(allRaces['track_id'].values)
plt.show()
```


![png](output_16_0.png)


As you can see this is a very uneven distribution. Track 12 seems to be the most popular by far. 
Lets check the absolute numbers


```python
allRaces['track_id'].value_counts()
```




    12    104878
    3      38114
    5      10901
    8       2206
    7       2132
    4       1995
    10      1806
    13      1471
    9        903
    6        797
    11       777
    14       629
    Name: track_id, dtype: int64



We will get back analyzing the track data so lets just save the amount of races per track and the IDs


```python
# Lets save that
tracks = pd.DataFrame(allRaces['track_id'].value_counts())
tracks.columns = ['races']
tracks.index.name = 'track_id'
```

### 2.3 Cont' fuel_consumption and weather
As track 12 is the most popular, lets check wether there is an correlation between the fuel_consumption and the weather on this one


```python
# The most popular track seems to be track 12, so lets check our "weather affects fuel_consumption"-hypothesis only on track 12
finishedOnTrack12 = finished.loc[allRaces['track_id'] == 12]
finishedOnTrack12.groupby(['weather'], as_index=False).mean()[['weather', 'fuel_consumption']]
```




<div>
<style>
    .dataframe thead tr:only-child th {
        text-align: right;
    }

    .dataframe thead th {
        text-align: left;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>weather</th>
      <th>fuel_consumption</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>rainy</td>
      <td>9.457026</td>
    </tr>
    <tr>
      <th>1</th>
      <td>snowy</td>
      <td>9.709260</td>
    </tr>
    <tr>
      <th>2</th>
      <td>sunny</td>
      <td>9.362550</td>
    </tr>
    <tr>
      <th>3</th>
      <td>thundery</td>
      <td>9.799436</td>
    </tr>
  </tbody>
</table>
</div>



There still seems to be no significant correlation between the weather and the fuel_consumption. But there is still a small effect. We can say that driving in the sun takes slightly less fuel than in thundery weather

### 2.4 Cont' popular tracks and pareto's law


```python
# Lets further investigate the track preferances of the players, this time in percentages
popularity = allRaces['track_id'].value_counts() / allRaces['track_id'].value_counts().values.sum() * 100

plt.figure(figsize = (16,4))
popularity.plot.bar()
```




    <matplotlib.axes._subplots.AxesSubplot at 0xe088f50>




![png](output_25_1.png)


As you can see, track 12 and 3 account to over 84% of the races. This is parettos law: 2/12 tracks account for more than 80% of the races. The remaining 10 tracks only accout for about 14% of the races.


```python
# Lets save that
tracks['pupularity'] = popularity
```

### 2.5 Which track gets finished more/less often?
Not all races get finished, many of them get canceled before and some after start. Lets check wether some tracks have more canceled races than others.  


```python
# Are there any maps that get finished more often?
finishedRatio = finished['track_id'].value_counts() / allRaces['track_id'].value_counts() * 100
finishedRatio = finishedRatio.sort_values()

plt.figure(figsize = (16,4))
finishedRatio.plot.bar(logy=True)
```




    <matplotlib.axes._subplots.AxesSubplot at 0xf1df8f0>




![png](output_29_1.png)


The most finished track is track 14, the track that gets finished the least is track 3. As track 3 and 12 are the most popular tracks, it is interesting to see that they have quite a big gap regarding the finished to unfinished races ratio. Track 3 gets finished a lot less than track 12.


```python
# Lets save that
tracks['finishedRatio'] = finishedRatio
```

### 2.6 How does fuel_consumption differ on multiple tracks?
As the tracks are probably different in length, it is likely that they also differ in average fuel_consumption. Lets check that, for obvious reasons lets only consider finished races


```python
meanFuelConsumption = pd.DataFrame(finished[['track_id', 'fuel_consumption']].dropna().groupby(['track_id'], as_index=False).mean())
meanFuelConsumption = meanFuelConsumption.set_index(['track_id'])
meanFuelConsumption.sort_values('fuel_consumption').plot.bar()
```




    <matplotlib.axes._subplots.AxesSubplot at 0xfda47b0>




![png](output_33_1.png)


There is quite a range of neccessary fuel for the different tracks. Probably they differ a lot in length. We can assume that probably track 4 is the shortest and track 14 the longest. By this meassure track 14 is probably more than 20 times longer than track 4. The most popular track 12 is pretty much in the middle with its needed fuel of 9.48 units on average.


```python
# Lets save that
tracks['meanFuelConsumption'] = meanFuelConsumption['fuel_consumption']
```

### 2.7 How much money do the players pay on the different tracks?
Lets take the averages for all tracks


```python
# Lets also include the average money per track
meanMoney = pd.DataFrame(finished[['track_id', 'fuel_consumption', 'money']].dropna().groupby(['track_id'], as_index=False).mean())
meanMoney = meanMoney.set_index(['track_id'])

plt.figure(figsize = (16,4))
meanMoney.sort_values('money')['money'].plot.bar()
```




    <matplotlib.axes._subplots.AxesSubplot at 0xfd16d70>




![png](output_37_1.png)


Track 12, which is the most popular has ranks very high when we compare the money. An explenation for that could be that only new players who dont have a lot of money play the other maps and the more experienced and 'richer' players play only track 12 and 6. But this is just a theory.


```python
# Lets save that
tracks['meanMoney'] = meanMoney['money']
```

### 2.8 Lets find correlations
We got quite some knowladge about the different tracks now. Take a look at the table bellow to see what we got. Lets find some correlations between the values.


```python
tracks
```




<div>
<style>
    .dataframe thead tr:only-child th {
        text-align: right;
    }

    .dataframe thead th {
        text-align: left;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>races</th>
      <th>pupularity</th>
      <th>finishedRatio</th>
      <th>meanFuelConsumption</th>
      <th>meanMoney</th>
    </tr>
    <tr>
      <th>track_id</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>12</th>
      <td>104878</td>
      <td>62.948580</td>
      <td>67.511776</td>
      <td>9.483578</td>
      <td>2699.662897</td>
    </tr>
    <tr>
      <th>3</th>
      <td>38114</td>
      <td>22.876315</td>
      <td>59.455843</td>
      <td>12.567264</td>
      <td>279.959315</td>
    </tr>
    <tr>
      <th>5</th>
      <td>10901</td>
      <td>6.542864</td>
      <td>64.397762</td>
      <td>4.817917</td>
      <td>1402.618701</td>
    </tr>
    <tr>
      <th>8</th>
      <td>2206</td>
      <td>1.324058</td>
      <td>63.961922</td>
      <td>13.147491</td>
      <td>316.334545</td>
    </tr>
    <tr>
      <th>7</th>
      <td>2132</td>
      <td>1.279643</td>
      <td>74.953096</td>
      <td>2.592874</td>
      <td>194.263502</td>
    </tr>
    <tr>
      <th>4</th>
      <td>1995</td>
      <td>1.197414</td>
      <td>63.909774</td>
      <td>0.923791</td>
      <td>349.598901</td>
    </tr>
    <tr>
      <th>10</th>
      <td>1806</td>
      <td>1.083975</td>
      <td>66.666667</td>
      <td>4.731765</td>
      <td>114.959044</td>
    </tr>
    <tr>
      <th>13</th>
      <td>1471</td>
      <td>0.882905</td>
      <td>65.941536</td>
      <td>2.421139</td>
      <td>263.209809</td>
    </tr>
    <tr>
      <th>9</th>
      <td>903</td>
      <td>0.541988</td>
      <td>71.871539</td>
      <td>3.621559</td>
      <td>1224.504695</td>
    </tr>
    <tr>
      <th>6</th>
      <td>797</td>
      <td>0.478366</td>
      <td>68.381430</td>
      <td>12.696661</td>
      <td>3363.821946</td>
    </tr>
    <tr>
      <th>11</th>
      <td>777</td>
      <td>0.466361</td>
      <td>62.162162</td>
      <td>12.920609</td>
      <td>157.173210</td>
    </tr>
    <tr>
      <th>14</th>
      <td>629</td>
      <td>0.377531</td>
      <td>75.993641</td>
      <td>18.831907</td>
      <td>1062.404819</td>
    </tr>
  </tbody>
</table>
</div>



That is how our tracks table looks like, now lets take a look on the correlation table. First the numbers and then the heatmap


```python
tracks.corr()
```




<div>
<style>
    .dataframe thead tr:only-child th {
        text-align: right;
    }

    .dataframe thead th {
        text-align: left;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>races</th>
      <th>pupularity</th>
      <th>finishedRatio</th>
      <th>meanFuelConsumption</th>
      <th>meanMoney</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>races</th>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>-0.159806</td>
      <td>0.123604</td>
      <td>0.434617</td>
    </tr>
    <tr>
      <th>pupularity</th>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>-0.159806</td>
      <td>0.123604</td>
      <td>0.434617</td>
    </tr>
    <tr>
      <th>finishedRatio</th>
      <td>-0.159806</td>
      <td>-0.159806</td>
      <td>1.000000</td>
      <td>0.010400</td>
      <td>0.219718</td>
    </tr>
    <tr>
      <th>meanFuelConsumption</th>
      <td>0.123604</td>
      <td>0.123604</td>
      <td>0.010400</td>
      <td>1.000000</td>
      <td>0.252360</td>
    </tr>
    <tr>
      <th>meanMoney</th>
      <td>0.434617</td>
      <td>0.434617</td>
      <td>0.219718</td>
      <td>0.252360</td>
      <td>1.000000</td>
    </tr>
  </tbody>
</table>
</div>




```python
# Lets see if there is any correlations between the different attributes of the tracks
import seaborn as sns

plt.figure(figsize = (16,9))

corr = tracks.corr()
sns.heatmap(corr, 
            xticklabels=corr.columns.values,
            yticklabels=corr.columns.values)
```




    <matplotlib.axes._subplots.AxesSubplot at 0xff92550>




![png](output_44_1.png)


There is quite a correlation between popularity and meanMoney. We stated an explenation for that in the previous chapter. The other correlations are not very strong.

### 2.9 Is there a correlation between the popularity of a track and the money?
Lets investigate this by visualising


```python
# There seems to be a correlation between the Money and the popularity of the track, lets investigate
x, y = tracks[['pupularity', 'meanMoney']].values.T
plt.scatter(x, y)
plt.ylabel("Popularity")
plt.xlabel("Mean Money")
plt.show()
```


![png](output_47_0.png)


Track 12 is an outlayer. It seems to be a litte far fatched to talk of a correlation here, but it is interesting that the most popular track is also one of the ones with the heighest mean money. Maybe only casual players with little money race on the other maps.

### 2.10 What is the most likely weather?


```python
plt.figure(figsize = (7,7))
(allRaces['weather'].value_counts() / allRaces['weather'].value_counts().sum() * 100).plot.pie()
```




    <matplotlib.axes._subplots.AxesSubplot at 0xe09b9d0>




![png](output_50_1.png)


Sunny is the most likely. How about on the different tracks?


```python
tracksWeather = pd.DataFrame(columns=('rainy', 'snowy', 'sunny', 'thundery'))
tracksWeather.index.name = 'track_id'

for x in range(3, 15):
    onlyTrack = allRaces.loc[allRaces['track_id'] == x]
    tracksWeather.loc[x] = onlyTrack['weather'].value_counts(normalize=True).sort_index().values

tracksWeather
```




<div>
<style>
    .dataframe thead tr:only-child th {
        text-align: right;
    }

    .dataframe thead th {
        text-align: left;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>rainy</th>
      <th>snowy</th>
      <th>sunny</th>
      <th>thundery</th>
    </tr>
    <tr>
      <th>track_id</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>3</th>
      <td>0.248268</td>
      <td>0.125502</td>
      <td>0.500375</td>
      <td>0.125855</td>
    </tr>
    <tr>
      <th>4</th>
      <td>0.259608</td>
      <td>0.116863</td>
      <td>0.492549</td>
      <td>0.130980</td>
    </tr>
    <tr>
      <th>5</th>
      <td>0.254416</td>
      <td>0.125071</td>
      <td>0.492165</td>
      <td>0.128348</td>
    </tr>
    <tr>
      <th>6</th>
      <td>0.253211</td>
      <td>0.130275</td>
      <td>0.506422</td>
      <td>0.110092</td>
    </tr>
    <tr>
      <th>7</th>
      <td>0.232791</td>
      <td>0.133917</td>
      <td>0.518148</td>
      <td>0.115144</td>
    </tr>
    <tr>
      <th>8</th>
      <td>0.253012</td>
      <td>0.115521</td>
      <td>0.503189</td>
      <td>0.128278</td>
    </tr>
    <tr>
      <th>9</th>
      <td>0.269646</td>
      <td>0.130971</td>
      <td>0.471495</td>
      <td>0.127889</td>
    </tr>
    <tr>
      <th>10</th>
      <td>0.230897</td>
      <td>0.126246</td>
      <td>0.503322</td>
      <td>0.139535</td>
    </tr>
    <tr>
      <th>11</th>
      <td>0.256729</td>
      <td>0.120083</td>
      <td>0.509317</td>
      <td>0.113872</td>
    </tr>
    <tr>
      <th>12</th>
      <td>0.250674</td>
      <td>0.122661</td>
      <td>0.502945</td>
      <td>0.123720</td>
    </tr>
    <tr>
      <th>13</th>
      <td>0.260825</td>
      <td>0.138144</td>
      <td>0.471134</td>
      <td>0.129897</td>
    </tr>
    <tr>
      <th>14</th>
      <td>0.215481</td>
      <td>0.142259</td>
      <td>0.514644</td>
      <td>0.127615</td>
    </tr>
  </tbody>
</table>
</div>



The distribution of the probabilites for the different weathers seem to be quite similar on the different tracks. Eighter is is random or players allways choose the weather with always the same chances on every track.


```python
# Lets save that
tracks = tracks.join(tracksWeather)
```

### 2.11 On which weather do the player spend the most money?


```python
weatherMoneyData = finished.groupby(['weather'], as_index=False).mean()[['weather', 'money']].sort_values("money")
weatherMoneyData.plot.bar(x = weatherMoneyData['weather'].values, logy=True)
```




    <matplotlib.axes._subplots.AxesSubplot at 0x14146f90>




![png](output_56_1.png)


They spend the most money in the sun and the least in the thunder

### 2.12 Is the opponent or the challenger more likely to win?


```python
challenger = 0
opponent = 0

for row in finished.itertuples():
    if getattr(row, 'winner') == getattr(row, 'challenger'):
        challenger = challenger + 1
    elif getattr(row, 'winner') == getattr(row, 'opponent'):
        opponent = opponent + 1
    else:
        raise Exception('Winner is nighter opponent nor challenger')
        
challenger / (challenger + opponent) * 100
```




    56.076590986168526



The challenger is slightly more likely to win. Challengers in 56% of the time. We can use that later as a feature for our prediction of races.

### 2.13 Do older accounts win over newer accouts?
Older accounts should have a lower id-number, while newer accounts should have a heigher one. Therefore could lower id drivers have more experience and win more often. Lets check if that is true.


```python
lowerId = 0
higherId = 0

for row in finished.itertuples():
    winnerId = getattr(row, 'winner')
    loserId = -1
    if winnerId == getattr(row, 'challenger'):
        loserId = getattr(row, 'opponent')
    elif winnerId == getattr(row, 'opponent'):
        loserId = getattr(row, 'challenger')
        
    if loserId == -1:
        raise Exception('Something went wrong')
    
    if winnerId > loserId:
        higherId = higherId + 1
    elif winnerId < loserId:
        lowerId = lowerId + 1
    else:
        raise Exception("Something went wrong")
    
olderAccountsWin = lowerId / (lowerId + higherId) * 100

plt.figure(figsize = (7,7))
plt.pie([olderAccountsWin, 100 - olderAccountsWin], labels=["Lower ID wins", "Higher ID wins"])
```




    ([<matplotlib.patches.Wedge at 0x144c8610>,
      <matplotlib.patches.Wedge at 0x144c8f50>],
     [<matplotlib.text.Text at 0x144c8bb0>, <matplotlib.text.Text at 0x144d2510>])




![png](output_62_1.png)


This hypothesis can assumed to be true, lowerIds (probably older accounts) win significantly more often than higher ids (66%). We can also use that later as a feature for our prediction of races.

### 2.14 How many races get finished?


```python
allRaces['status'].value_counts(normalize=True) * 100
```




    finished    65.482057
    retired     25.943376
    declined     6.837566
    waiting      1.737001
    Name: status, dtype: float64




```python
plt.figure(figsize = (7,7))
allRaces['status'].value_counts(normalize=True).plot.pie()
```




    <matplotlib.axes._subplots.AxesSubplot at 0x141c86d0>




![png](output_66_1.png)


Only 65% of all races get finished. All the others are declined, retired or waiting.

### 2.15 On which weekdays happen the most races? 


```python
# First we convert the string of race_driven into datetimes
allRaces['race_driven'] = pd.to_datetime(allRaces['race_driven'], errors='coerce')
```


```python
# Lets create a field for weekdays
allRaces['weekday'] = allRaces.apply(lambda row: row['race_driven'].isoweekday(), axis=1)
```


```python
plt.figure(figsize = (16,4))
allRaces['weekday'].value_counts().sort_index().plot.line()
```




    <matplotlib.axes._subplots.AxesSubplot at 0x13806c90>




![png](output_71_1.png)


Most races are done on sunday and monday. Thursday and friday are the days in which the least races happen.

### 2.16 At which times happen the most races?


```python
allRaces['hour'] = allRaces.apply(lambda row: row['race_driven'].hour, axis=1)
```


```python
plt.figure(figsize = (16,4))
allRaces['hour'].value_counts().sort_index().plot.line()
```




    <matplotlib.axes._subplots.AxesSubplot at 0x17d71f90>




![png](output_75_1.png)


The most popular hours for races are 21:00 and 20:00. Between 3:00 and 5:00 are the least popular. Just as expected.

### 2.17 How did the amount of races per month develope? 


```python
import datetime
import math
import time

firstDate = allRaces.values[0][1].timestamp();
allRaces['time_number'] = allRaces.apply(lambda row: (row['race_driven'].timestamp() - firstDate), axis=1, ignore_failures=True)
dates = allRaces.dropna().apply(lambda row: int(row['time_number'] / 60 / 60 / 24 / 30), axis=1, ignore_failures=True)
```


```python
y = dates.value_counts().values
x = dates.value_counts().index

plt.figure(figsize = (16,4))
plt.scatter(x, y)
plt.ylabel("Races")
plt.xlabel("Month")
plt.show()
```


![png](output_79_0.png)


As you can see in the chart, the first couple of months there was a spike in players and then a steady decline after the 20th month. There are little spikes in regular intervals but it looks quite smooth.

## 3 Prediction
Given two players we want to predict the outcome of the race. First of all we have to engineer some features.

### 3.1 Features

#### Feature ideas
1. Who is the challanger? As seen before, this has some predictive value.
2. Who had more games? I think the more games a player had, the more experieced and skilled he should be.
3. Who has the older account? We have proofen before that this has predictive value.
4. Who won more games? People who win more probably have a higher chance to win again.
5. Who has a higher win/loos ratio? Not only absolute wins but also wins in relation to losses are important.
6. Who won more games agains the same opponend? If those two players played against each other before, we should know about that.

We are developing a function now that returns these features in relation between the two players. We only regard races that have been completed before the current time, this makes sure our algorithm cant look into the future.  


```python
rp = allRaces.dropna()
def getPredictionFeatures(time, challenger, opponent):
    challenger_games = rp[(rp.time_number < time) & ((rp.challenger == challenger) | (rp.opponent == challenger))]
    challenger_wins = challenger_games[challenger_games.winner == challenger]
    
    opponent_games = rp[(rp.time_number < time) & ((rp.challenger == opponent) | (rp.opponent == opponent))]
    opponent_wins = opponent_games[opponent_games.winner == opponent]
    
    samesetup_games_ids = opponent_games.index.intersection(challenger_games.index)
    samesetup_games = rp[rp.index.isin(samesetup_games_ids)]
        
    if opponent_games.shape[0] + challenger_games.shape[0] != 0:
        gamesindex = challenger_games.shape[0] / (opponent_games.shape[0] + challenger_games.shape[0])
    else:
        gamesindex = 0.5
    
    if opponent_wins.shape[0] + challenger_wins.shape[0] != 0:
        winindex = challenger_wins.shape[0] / (opponent_wins.shape[0] + challenger_wins.shape[0])
    else:
        winindex = 0.5
    
    if challenger_games.shape[0] != 0 and opponent_games.shape[0] != 0:
        challengerWinCount = challenger_wins.shape[0] / challenger_games.shape[0]
        if (challengerWinCount + (opponent_wins.shape[0] / opponent_games.shape[0])) != 0:
            winCountIndex = challengerWinCount / (challengerWinCount + (opponent_wins.shape[0] / opponent_games.shape[0]))
        else:
            winCountIndex = 0.5
    else:
        winCountIndex = 0.5
    
    if samesetup_games.shape[0] != 0:
        samesetupWinIndex = samesetup_games[samesetup_games.winner == challenger].shape[0] / samesetup_games.shape[0]
    else:
        samesetupWinIndex = 0.5
    
    accountAgeIndex = int(challenger > opponent)
    
    return gamesindex, winindex, winCountIndex, samesetupWinIndex, accountAgeIndex
```

Lets now see how the feature array would look like


```python
getPredictionFeatures(1666080, 5, 4)
```




    (0.9858044164037855, 0.9943117178612059, 0.7156764625602766, 0.5, 1)



All these values can range from 0 (bad for the challenger) to 1 (good for the challenger). If the algorithm runs into a division by zero (means there are no samples) it will return the variable as 0.5 

We calculate now all the features and the outcomes from all the finished games and put them in our x (features) and y (outcome) array. We always provide the current timestamp to ensure the algorithm cant look into the future.


```python
x = []
y = []

for index, row in rp.iterrows():
    pred = getPredictionFeatures(row.time_number, row.challenger, row.opponent)
    truth = int(row.winner == row.challenger)
    x.append(pred)
    y.append(truth)
```

### 3.2 Training and test data

Now we split our x and y data into training and test datasets (80%/20%). We use sklearn for machine learning


```python
from sklearn.model_selection import train_test_split
x_train, x_test, y_train, y_test = train_test_split(x, y, test_size=0.2)  
```

### 3.3 Machine Learning

Now we train the machine learning algorithm of our choice with the training data and print out how he scores with our testing data. We treat this as a classification problem and therefore predict "Is the challenger going to win?". If the awnser is 0, then our prediction is "No", if the awnser is 1, then our prediction is "Yes, he is going to"

First we give all the features to the GradientBoostingClassifier. I tried a lot of different algorithms, this one seems to work quite well.


```python
from sklearn.ensemble import GradientBoostingClassifier

clf = GradientBoostingClassifier(learning_rate=0.5, n_estimators=10)
clf.fit(x_train, y_train)
clf.score(x_test, y_test)
```




    0.75111202354068296



A precition of 75% is quite good, lets see which features are the most important


```python
clf.feature_importances_
```




    array([ 0.1297123 ,  0.18002243,  0.28746246,  0.26336691,  0.1394359 ])



Especially feature 3 (winCountIndex) and feature 4 (samesetupWinIndex) are useful for the algorithm. Makes sense, as they provide information about the experience of the players and about their previous matches against each other.

Lets see if these features are enough for the algorithm. Maybe the other features are just noise, so lets remove them and try again: 


```python
x_man = np.array(x)[:,1:4]
x_man_train, x_man_test, y_man_train, y_man_test = train_test_split(x_man, y, test_size=0.2)
```


```python
clf_man = GradientBoostingClassifier(learning_rate=0.5, n_estimators=10)
clf_man.fit(x_man_train, y_man_train)
clf_man.score(x_man_test, y_man_test)
```




    0.74502155614863474



The performance is slightly worse but quite similar. While these features are enough for the algorithm to perform well, the others still seem to help a little.

Lets now automatically select the best two features with the chi2 algorithm and check how the model performes with these:


```python
from sklearn.feature_selection import SelectKBest
from sklearn.feature_selection import chi2

x_selected = SelectKBest(chi2, k=2).fit_transform(x, y)
x_selected_train, x_selected_test, y_selected_train, y_selected_test = train_test_split(x_selected, y, test_size=0.2)
```


```python
clf_auto = GradientBoostingClassifier(learning_rate=0.5, n_estimators=10)
clf_auto.fit(x_selected_train, y_selected_train)
clf_auto.score(x_selected_test, y_selected_test)
```




    0.7037569287620612



As we can see the precition gets even worse. Therefore we can conclude that all our features are useful for the algorithm.
Our final precition is 75% with the first (and complete) set of features.

### 3.4 Predicting

As you can se we got a precition of 75%, I guess that is decent. We can might that score by trying other algorithms and other settings.

Now lets use our model to predict the 200ed race:


```python
print("Prediction: " + str(clf.predict([x[200]])))
print("Truth: " + str([y[200]]))
```

    Prediction: [1]
    Truth: [1]
    

In this case we are lucky and the prediction and the truth are equal. As the precition is 75% it will be correct 75% of the time.

Thank you for reading :)
